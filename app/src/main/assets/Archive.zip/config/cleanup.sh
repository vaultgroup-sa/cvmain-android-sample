#!/bin/bash

#cleans up the current dir to make for a clean install

echo "About to cleanup the current directory."
echo "ALL DATA EXCEPT AUTHENTICATION INFO AND MAPPING WILL BE LOST!!!!"
echo "Type yes and press enter to proceed. Anything else aborts the cleanup"
read line
if [ "${line}" != "yes" ];
then
	echo "Aborted. Cleanup did not start.";
	exit 1;
fi

echo "Proceeding with cleanup now"

for file in cards.db lock_state.json main_db;
do
	rm -f ${file}
done
		
rm -f var/cards/* 
rm -f var/cards/*~
rm -f var/duress/*
rm -f var/duress/*~
rm -f *~
rm -f .*~

echo "Cleanup complete"

