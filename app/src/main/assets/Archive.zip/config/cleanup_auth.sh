#!/bin/bash

echo "This will clear the auth data"
echo "no other files will be removed (use the cleanup.sh script for that)"
echo "WARNING: YOU WILL NEED TO RE-REGISTER THE DEVICE IF YOU DO THIS!!!"
echo "Type yes and press Enter to proceed. Anything else aborts"
read line
if [ "${line}" != "yes" ];
then
	echo "Aborted";
	exit 1;
fi

rm -f auth.json

echo "Authentication info deleted"


