#!/usr/bin/python3

#this script generates a duress message in var/duress/duress

import datetime

dt = datetime.datetime.utcnow().isoformat() + "Z";

f = open("var/duress/duress", "w")
f.write(dt)
f.flush()
f.close()

