#!/usr/bin/python3

#this script can be used to test the rfid system.
#When called without any params, a random rfid card value is
#generated. When called with 1 param, that value is used when
#generating a card

import random
import math
import datetime
import sys

code = ""
if len(sys.argv) == 1:
    print("Generating file for random rfid code")
elif len(sys.argv) == 2:
    code = sys.argv[1]
    print("Generating file for rfid code: " + code)
else:
    print("Usage: " + sys.argv[0] + " [optional code]");
    sys.exit(1)

if code == "":
    #generate a random code
    for j in range(0,10):
        rand = random.random() * 10;
        rand = math.floor(rand);
        code += str(rand);

dt = datetime.datetime.utcnow().isoformat() + "Z";

f = open("var/cards/rfid_card", "w")
f.write(code + "\n")
f.write(dt)
f.flush()
f.close()

