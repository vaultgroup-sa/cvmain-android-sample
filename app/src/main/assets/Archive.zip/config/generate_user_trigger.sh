#!/bin/bash

#generates a user trigger file. This is what the trigger_user_duress endpoint does

touch var/duress/user_duress

